<footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="mb-5">
                    <h3 class="footer-heading mb-4">About Apart</h3>
                    <p>We are here to help you with your next holiday and we take care to ensure you are matched with your ideal holiday accommodation. All holiday rental properties inspected and known intimately and we use this information to answer any questions you may have.</p>
                </div>

            </div>
            <div class="col-lg-4 mb-5 mb-lg-0">
                <div class="row mb-5">
                    <div class="col-md-12">
                        <h3 class="footer-heading mb-4">Navigations</h3>
                    </div>
                    <div class="col-md-6 col-lg-6">
                        <ul class="list-unstyled">
                            <li><a href="/">Home</a></li>
                            <li><a href="apartments">Apartments</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-lg-6">
                        <ul class="list-unstyled">
                            <li><a href="about">About Us</a></li>
                            <li><a href="contact">Contact Us</a></li>

                        </ul>
                    </div>
                </div>



            </div>



        </div>
        <div class="row pt-5 mt-5 text-center">
            <div class="col-md-12">
                <p>

                 All rights reserved | Filuro
                </p>
            </div>

        </div>
    </div>
</footer>