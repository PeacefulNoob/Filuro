<div class="socials">
<div class="bg-primary" data-aos="fade">
    <div class="container">
        <div class="row">
            <a href="#" class="col-3 text-center py-4 d-block si"><i class="fa fa-facebook text-white"></i></a>
            <a href="#" class="col-3 text-center py-4  d-block si"><i class="fa fa-facebook text-white"></i></a>
            <a href="#" class="col-3 text-center py-4  d-block si"><i class="fa fa-facebook text-white"></i></a>
            <a href="#" class="col-3 text-center py-4  d-block si"><i class="fa fa-facebook text-white"></i></a>
        </div>
    </div>
</div>
</div>