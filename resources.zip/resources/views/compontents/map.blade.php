<section id = "map">
<div class="map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2082.6077184445803!2d18.764125239006496!3d42.42236894187398!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x713eda3ede323413!2sFiluro!5e0!3m2!1sen!2s!4v1590659465814!5m2!1sen!2s" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></div>
   </section>