<h4>Za apartman </h4>
<p>{{ $aptName }}</p>
<h4>Ime i prezime </h4>
<p>{{ $name }}</p>

<h4>Email adresa</h4>
<p>{{ $email }}</p>
<h4>Poruka</h4>
<p>{{ $content }}</p>
<h4>Subjekt</h4>
<p>{{ $subject }}</p>